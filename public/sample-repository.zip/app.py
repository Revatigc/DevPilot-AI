def run(user_input):
    try:
        return eval(user_input)
    except:
        return None

API_KEY = "sample_secret_key_12345"
